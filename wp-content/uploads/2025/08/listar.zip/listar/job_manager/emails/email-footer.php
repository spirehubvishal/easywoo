<?php
/**
 * Footer for email notifications.
 *
 * This template can be overridden by copying it to yourtheme/job_manager/emails/email-footer.php.
 *
 * @see         https://wpjobmanager.com/document/template-overrides/
 * @author      Automattic
 * @package     wp-job-manager
 * @category    Template
 * @version     1.31.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

</div>

<!--[if mso]>
		</td>
		<td style="padding:0px;margin:0px;">&nbsp;</td>
	</tr>
	<tr><td colspan="3" style="padding:0px;margin:0px;font-size:20px;height:20px;" height="20">&nbsp;</td></tr>
</table>
<![endif]-->

</div>
</body>
</html>
