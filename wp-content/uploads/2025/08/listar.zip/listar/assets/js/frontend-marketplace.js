/**
 Theme Name:         Listar
 Theme URI:          http://listar.directory/
 Author:             Web Design Trade
 Author URI:         https://themeforest.net/user/webdesigntrade
 File Description:   Custom JavaScript for Front End Marketplace

 @package Listar
 */

window.$ = window.$ || {};

( function ( $ ) {
	
} )( jQuery );