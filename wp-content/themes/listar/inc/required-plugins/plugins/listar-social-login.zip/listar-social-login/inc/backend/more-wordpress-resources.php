<?php defined('ABSPATH') or die("No script kiddies please!"); ?>
<div class="about-wrapper clearfix">
    <div class="about-desc-wrap clearfix">
        <div class="lsl-title">
            <h3>More WordPress Resources</h3>
        </div>
    </div>
</div>