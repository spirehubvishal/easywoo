<div class="lsl-setting-header clearfix">
    <div class="lsl-headerlogo">
     	<div class="logo-wrap">  <img src="<?php echo LSL_IMAGE_DIR; ?>/logo.png" alt="<?php esc_attr_e('Listar Social Login', LSL_TEXT_DOMAIN); ?>" /></div>
    	<div class="logo-content"><?php esc_attr_e('Listar Social Login', LSL_TEXT_DOMAIN); ?><br />
    		<span class='plugin-version'><?php esc_attr_e('version '.LSL_VERSION, LSL_TEXT_DOMAIN ); ?></span>
    	</div>
    </div>
    <div class="lsl-right-header-block">
    </div>
    <div class="clear"></div>
</div>