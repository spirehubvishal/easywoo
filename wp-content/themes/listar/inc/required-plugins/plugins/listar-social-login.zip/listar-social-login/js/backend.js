function showMappingConfirm( field ){
        if(typeof jQuery=="undefined"){
            alert( "Error: Listar Social Login require jQuery to be installed on your wordpress in order to work!" );

            return false;
        }

        var el = jQuery( "#bb_profile_mapping_selector_" + field ).val();

        jQuery( ".bb_profile_mapping_confirm_" + field ).hide();

        jQuery( "#bb_profile_mapping_confirm_" + field + "_" + el ).show();
    }

jQuery(document).ready(function($) {
    //for sorting the social networks
    $('.network-settings').sortable({
        containment: "parent",
    });
    
    //for the tabs
    $('.nav-tab').click(function() {
        $('.nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        var tab_id = 'tab-' + $(this).attr('id');
        $('.lsl-tab-contents').hide();
        $('#' + tab_id).show();
    });
    $('.lsl-label').click(function() {
        $(this).closest('.lsl-settings').find('.lsl_network_settings_wrapper').toggle('slow', function() {
            if ($(this).closest('.lsl-settings').find('.lsl_network_settings_wrapper').is(':visible')) {
                $(this).closest('.lsl-settings').find('.lsl_show_hide i').removeClass('fa-caret-down');
                $(this).closest('.lsl-settings').find('.lsl_show_hide i').addClass('fa-caret-up');
            } else {
                $(this).closest('.lsl-settings').find('.lsl_show_hide i').removeClass('fa-caret-up');
                $(this).closest('.lsl-settings').find('.lsl_show_hide i').addClass('fa-caret-down');
            }
        });
    });
    // for hide show options based on logout redirect options 
    $('.lsl_custom_logout_redirect_options').click(function() {
        if ($(this).val() === 'custom_page') {
            $('.lsl-custom-logout-redirect-link').show('slow');
        } else {
            $('.lsl-custom-logout-redirect-link').hide('show');
        }
    });
    // for hide show options based on logout redirect options
    $('.lsl_custom_login_redirect_options').click(function() {
        if ($(this).val() === 'custom_page') {
            $('.lsl-custom-login-redirect-link').show('slow');
        } else {
            $('.lsl-custom-login-redirect-link').hide('show');
        }
    });
    // for hide show options based on logout redirect options
    $('.lsl_send_email_notification_options').click(function() {
        if ($(this).val() === 'yes') {
            $('.lsl-email-format-settings').show('slow');
        } else {
            $('.lsl-email-format-settings').hide('show');
        }
    });

    // for hide show options based on logout redirect options
    $('.lsl_profile_mapping_options').click(function() {
        if ($(this).val() === 'yes') {
            $('.lsl-profile-mapping-outer').show('slow');
        } else {
            $('.lsl-profile-mapping-outer').hide('show');
        }
    });
});