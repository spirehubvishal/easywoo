<div class='lsl-settings'>
    <div class='lsl-enable-disable-opt'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-icon-social-login"><i class="fa fa-bars" aria-hidden="true"></i></span> <?php esc_attr_e('Social Login', LSL_TEXT_DOMAIN); ?><span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <p class="social-login">
                <span><?php esc_attr_e('Enable social login?', LSL_TEXT_DOMAIN); ?></span>
                <input type='radio' id='lsl_enable_plugin' name='lsl_enable_disable_plugin' value='yes' <?php checked($options['lsl_enable_disable_plugin'], 'yes', 'true'); ?> /> <label for='lsl_enable_plugin'>Yes</label>
                <input type='radio' id='lsl_disable_plugin' name='lsl_enable_disable_plugin' value='no' <?php checked($options['lsl_enable_disable_plugin'], 'no', 'true'); ?> /> <label for='lsl_disable_plugin'>No</label>
            </p>
            <p class="social-login-buddypress">
                <span><?php esc_attr_e('Enable social login in Buddypress?', LSL_TEXT_DOMAIN); ?></span>
                <input type='radio' id='lsl_enable_buddypress' name='lsl_enable_disable_buddypress' value='yes' <?php checked($options['lsl_enable_disable_buddypress'], 'yes', 'true'); ?> /> <label for='lsl_enable_buddypress'>Yes</label>
                <input type='radio' id='lsl_disable_buddypress' name='lsl_enable_disable_buddypress' value='no' <?php checked($options['lsl_enable_disable_buddypress'], 'no', 'true'); ?> /> <label for='lsl_disable_buddypress'>No</label>
            </p>
            <p class="social-login-woocommerce">
                <span><?php esc_attr_e('Enable social login in Woocommerce?', LSL_TEXT_DOMAIN); ?></span>
                <input type='radio' id='lsl_enable_woocommerce' name='lsl_enable_disable_woocommerce' value='yes' <?php checked($options['lsl_enable_disable_woocommerce'], 'yes', 'true'); ?> /> <label for='lsl_enable_woocommerce'>Yes</label>
                <input type='radio' id='lsl_disable_woocommerce' name='lsl_enable_disable_woocommerce' value='no' <?php checked($options['lsl_enable_disable_woocommerce'], 'no', 'true'); ?> /> <label for='lsl_disable_woocommerce'>No</label>
            </p>
            <p class="social-login">
                <span><?php esc_attr_e("Enable social login in EDD's login shortcode", LSL_TEXT_DOMAIN); ?></span>
                <input type='radio' id='lsl_enable_edd_login_shortcode' name='lsl_enable_disable_edd_login_shortcode' value='yes' <?php
                if (isset($options['lsl_enable_disable_edd_login_shortcode'])) {
                    checked($options['lsl_enable_disable_edd_login_shortcode'], 'yes', 'true');
                }
                ?> /> <label for='lsl_enable_edd_login_shortcode'><?php esc_attr_e("Yes", LSL_TEXT_DOMAIN); ?></label>
                <input type='radio' id='lsl_disable_edd_login_shortcode' name='lsl_enable_disable_edd_login_shortcode' value='no' <?php
                if (isset($options['lsl_enable_disable_edd_login_shortcode'])) {
                    checked($options['lsl_enable_disable_edd_login_shortcode'], 'no', 'true');
                } else {
                    echo "checked='checked'";
                }
                ?> /> <label for='lsl_disable_edd_login_shortcode'><?php esc_attr_e("No", LSL_TEXT_DOMAIN); ?></label>
            </p>
            <p class="social-login">
                <span><?php esc_attr_e("Enable social login in EDD's register shortcode", LSL_TEXT_DOMAIN); ?></span>
                <input type='radio' id='lsl_enable_edd_register_shortcode' name='lsl_enable_disable_edd_register_shortcode' value='yes' <?php
                if (isset($options['lsl_enable_disable_edd_register_shortcode'])) {
                    checked($options['lsl_enable_disable_edd_register_shortcode'], 'yes', 'true');
                }
                ?> /> <label for='lsl_enable_edd_register_shortcode'><?php esc_attr_e("Yes", LSL_TEXT_DOMAIN); ?></label>
                <input type='radio' id='lsl_disable_edd_register_shortcode' name='lsl_enable_disable_edd_register_shortcode' value='no' <?php
                if (isset($options['lsl_enable_disable_edd_register_shortcode'])) {
                    checked($options['lsl_enable_disable_edd_register_shortcode'], 'no', 'true');
                } else {
                    echo "checked='checked'";
                }
                ?> /> <label for='lsl_disable_edd_register_shortcode'><?php esc_attr_e("No", LSL_TEXT_DOMAIN); ?></label>
            </p>
            <p class="social-login">
                <span><?php esc_attr_e("Enable social login in EDD's checkout page?", LSL_TEXT_DOMAIN); ?></span>
                <input type='radio' id='lsl_enable_edd_checkout' name='lsl_enable_disable_edd_checkout' value='yes' <?php
                if (isset($options['lsl_enable_disable_edd_checkout'])) {
                    checked($options['lsl_enable_disable_edd_checkout'], 'yes', 'true');
                }
                ?> /> <label for='lsl_enable_edd_checkout'><?php esc_attr_e("Yes", LSL_TEXT_DOMAIN); ?></label>
                <input type='radio' id='lsl_disable_edd_checkout' name='lsl_enable_disable_edd_checkout' value='no' <?php
                if (isset($options['lsl_enable_disable_edd_checkout'])) {
                    checked($options['lsl_enable_disable_edd_checkout'], 'no', 'true');
                } else {
                    echo "checked='checked'";
                }
                ?> /> <label for='lsl_disable_edd_checkout'><?php esc_attr_e("No", LSL_TEXT_DOMAIN); ?></label>
            </p>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-display-options'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-icon-display-option"><i class="fa fa-window-maximize"></i></span> <?php esc_attr_e('Display Options', LSL_TEXT_DOMAIN); ?><span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span></div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <p><?php esc_attr_e('Please choose the options where you want to display the social login form.', LSL_TEXT_DOMAIN); ?></p>
            <p><input type="checkbox" id="lsl_login_form" value="login_form" name="lsl_display_options[]" <?php
                if (in_array("login_form", $options['lsl_display_options'])) {
                    echo "checked='checked'";
                }
                ?> ><label for="lsl_login_form"><?php esc_attr_e('Login Form', LSL_TEXT_DOMAIN); ?> </label></p>
            <p><input type="checkbox" id="lsl_register_form" value="register_form" name="lsl_display_options[]" <?php
                if (in_array("register_form", $options['lsl_display_options'])) {
                    echo "checked='checked'";
                }
                ?> ><label for="lsl_register_form"><?php esc_attr_e('Register Form', LSL_TEXT_DOMAIN); ?> </label></p>
            <p><input type="checkbox" id="lsl_comment_form" value="comment_form" name="lsl_display_options[]" <?php
                if (in_array("comment_form", $options['lsl_display_options'])) {
                    echo "checked='checked'";
                }
                ?> ><label for="lsl_comment_form"><?php esc_attr_e('Comments', LSL_TEXT_DOMAIN); ?> </label></p>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-user-role-opt'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-icon-user-role"><i class="fa fa-user-plus" aria-hidden="true"></i></span> <?php esc_attr_e('Set user role', LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <?php esc_attr_e('User role', LSL_TEXT_DOMAIN); ?>
            <?php
            if (isset($options['lsl_user_role'])) {
                $selected = $options['lsl_user_role'];
            } else {
                $selected = '';
            }
//echo $selected;
            ?>
            <select name='lsl_user_role'>
                <?php wp_dropdown_roles($selected); ?>
            </select>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-themes-wrapper'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-icon-theme"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> <?php esc_attr_e('Available Icon Themes', LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <?php for ($i = 1; $i <= 30; $i++): ?>
                <div class='lsl-theme lsl-theme-<?php echo $i; ?>'>
                    <label><input type="radio" id="lsl-theme-<?php echo $i; ?>" value="<?php echo $i; ?>" class="lsl-theme lsl-png-theme" name="lsl_icon_theme" <?php checked($i, $options['lsl_icon_theme']); ?> >
                        <span><?php esc_attr_e('Theme ' . $i, LSL_TEXT_DOMAIN); ?></span></label>
                    <div class="lsl-theme-previewbox">
                        <img src="<?php echo LSL_IMAGE_DIR; ?>/preview-<?php echo $i; ?>.<?php echo $i <= 17 ? 'jpg' : 'png'; ?>" alt="Login Template Theme Preview">
                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-text-settings'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-text-setting"><i class="fa fa-i-cursor" aria-hidden="true"></i></span> <?php esc_attr_e('Text Settings', LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none;'>
            <p class='lsl-title-text-field'>
                <span><?php esc_attr_e('Login text:', LSL_TEXT_DOMAIN); ?></span> <input type='text' name='lsl_title_text_field' id='lsl-title-text' value='<?php
                if (isset($options['lsl_title_text_field']) && $options['lsl_title_text_field'] != '') {
                    echo $options['lsl_title_text_field'];
                }
                ?>' />
            </p>

            <p class='lsl-each-login-short-text'>
                <span><?php esc_attr_e('Login short text:', LSL_TEXT_DOMAIN); ?></span> <input type='text' name='lsl_login_short_text' id='lsl-login-short-text' value='<?php
                if (isset($options['lsl_login_short_text']) && $options['lsl_login_short_text'] != '') {
                    echo $options['lsl_login_short_text'];
                }
                ?>' />
            <div class='lsl-info'><?php esc_attr_e('If this field is empty. The default "Login" text will appear.', LSL_TEXT_DOMAIN); ?></div>
            </p>

            <p class='lsl-each-login-long-text'>
                <span><?php esc_attr_e('Login with long text:', LSL_TEXT_DOMAIN); ?></span> <input type='text' name='lsl_login_with_long_text' id='lsl-login-with-long-text' value='<?php
                if (isset($options['lsl_login_with_long_text']) && $options['lsl_login_with_long_text'] != '') {
                    echo $options['lsl_login_with_long_text'];
                }
                ?>' />
            <div class='lsl-info'><?php esc_attr_e('If this field is empty. The default "Login with" text will appear for long text.', LSL_TEXT_DOMAIN); ?></div>
            </p>
            <p class='lsl-each-link-title-attribute'>
                <span><?php esc_attr_e('Hide Long Text:', LSL_TEXT_DOMAIN); ?></span> 
                <span><input type="checkbox" id="lsl_showhide_title_attr" value="hide" name="lsl_showhide_title_attr" <?php
                    if (isset($options['lsl_showhide_title_attr']) && $options['lsl_showhide_title_attr'] == 'hide') {
                        echo "checked='checked'";
                    }
                    ?> ><label for="lsl_showhide_title_attr"><?php esc_attr_e('Hide/Show', LSL_TEXT_DOMAIN); ?> </label></p>
            <div class='lsl-info'><?php esc_attr_e('If this field is empty, default "Login with" text will not appear. And social site title will only be shown. Override default behaviour. ', LSL_TEXT_DOMAIN); ?></div>
            </p>
            <p class='lsl-each-link-title-attribute'>
                <span><?php esc_attr_e('Link title attribute:', LSL_TEXT_DOMAIN); ?></span> <input type='text' name='lsl_each_link_title_attribute' id='lsl_each_link_title_attribute' value='<?php
                if (isset($options['lsl_each_link_title_attribute']) && $options['lsl_each_link_title_attribute'] != '') {
                    echo $options['lsl_each_link_title_attribute'];
                }
                ?>' />
            <div class='lsl-info'><?php esc_attr_e('If this field is empty. The default "Login with" text will appear.', LSL_TEXT_DOMAIN); ?></div>
            </p>

            <p class='lsl-login-error-message'>
                <span><?php esc_attr_e('Login error message:', LSL_TEXT_DOMAIN); ?></span> <input type='text' name='lsl_login_error_message' id='lsl_login_error_message' value='<?php
                if (isset($options['lsl_login_error_message']) && $options['lsl_login_error_message'] != '') {
                    echo $options['lsl_login_error_message'];
                }
                ?>' />
            <div class='lsl-info'><?php esc_attr_e('If this field is empty. The default "You have Access Denied. Please authorize the app to login." text will appear.', LSL_TEXT_DOMAIN); ?></div>
            </p>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-logout-redirect-settings'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-sign-out"><i class="fa fa-sign-out" aria-hidden="true"></i></span> <?php esc_attr_e('Logout Redirect Link', LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <input type='radio' id='lsl_custom_logout_redirect_home' class='lsl_custom_logout_redirect_options' name='lsl_custom_logout_redirect_options' value='home' <?php
            if (isset($options['lsl_custom_logout_redirect_options'])) {
                checked($options['lsl_custom_logout_redirect_options'], 'home', 'true');
            }
            ?> /> <label for='lsl_custom_logout_redirect_home'><?php esc_attr_e('Home page', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <input type='radio' id='lsl_custom_logout_redirect_current' class='lsl_custom_logout_redirect_options' name='lsl_custom_logout_redirect_options' value='current_page' <?php
            if (isset($options['lsl_custom_logout_redirect_options'])) {
                checked($options['lsl_custom_logout_redirect_options'], 'current_page', 'true');
            }
            ?> /> <label for='lsl_custom_logout_redirect_current'><?php esc_attr_e('Current page', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <input type='radio' id='lsl_custom_logout_redirect_custom' class='lsl_custom_logout_redirect_options' name='lsl_custom_logout_redirect_options' value='custom_page' <?php
            if (isset($options['lsl_custom_logout_redirect_options'])) {
                checked($options['lsl_custom_logout_redirect_options'], 'custom_page', 'true');
            }
            ?> /> <label for='lsl_custom_logout_redirect_custom'><?php esc_attr_e('Custom page', LSL_TEXT_DOMAIN); ?></label><br />

            <div class='lsl-custom-logout-redirect-link' <?php if ($options['lsl_custom_logout_redirect_options'] == 'custom_page') { ?> style='display: block' <?php } else { ?> style='display:none' <?php } ?>>
                <p class='lsl-title-text-field'>
                    <span><?php esc_attr_e('Logout redirect page:', LSL_TEXT_DOMAIN); ?></span> <input type='text' name='lsl_custom_logout_redirect_link' id='lsl-custom-logout-redirect-link' value='<?php
                    if (isset($options['lsl_custom_logout_redirect_link']) && $options['lsl_custom_logout_redirect_link'] != '') {
                        echo $options['lsl_custom_logout_redirect_link'];
                    }
                    ?>' />
                </p>
                <div class='lsl-info'>
                    <span class='lsl-info-note'><?php esc_attr_e('Note:', LSL_TEXT_DOMAIN); ?></span> <br />
                    <span class='lsl-info-content'><?php esc_attr_e('Please set this value if you want to redirect the user to the custom page url(full url). If this field is not set they will be redirected back to current page.', LSL_TEXT_DOMAIN); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-login-redirect-settings'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-sign-in"><i class="fa fa-sign-in" aria-hidden="true"></i></span> <?php esc_attr_e('Login Redirect Link', LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <input type='radio' id='lsl_custom_login_redirect_home' class='lsl_custom_login_redirect_options' name='lsl_custom_login_redirect_options' value='home' <?php
            if (isset($options['lsl_custom_login_redirect_options'])) {
                checked($options['lsl_custom_login_redirect_options'], 'home', 'true');
            }
            ?> /> <label for='lsl_custom_login_redirect_home'><?php esc_attr_e('Home page', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <input type='radio' id='lsl_custom_login_redirect_current' class='lsl_custom_login_redirect_options' name='lsl_custom_login_redirect_options' value='current_page' <?php
            if (isset($options['lsl_custom_login_redirect_options'])) {
                checked($options['lsl_custom_login_redirect_options'], 'current_page', 'true');
            }
            ?> /> <label for='lsl_custom_login_redirect_current'><?php esc_attr_e('Current page', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <div class='lsl-custom-login-redirect-link1' >
                <div class='lsl-info'>
                    <span class='lsl-info-note'><?php esc_attr_e('Note:', LSL_TEXT_DOMAIN); ?></span> <br />
                    <span class='lsl-info-content'> <?php esc_attr_e('If plugin can\'t detect what is the redirect uri for the page it will be redirected to home page.', LSL_TEXT_DOMAIN); ?></span>
                </div>
            </div>
            <input type='radio' id='lsl_custom_login_redirect_custom' class='lsl_custom_login_redirect_options' name='lsl_custom_login_redirect_options' value='custom_page' <?php
            if (isset($options['lsl_custom_login_redirect_options'])) {
                checked($options['lsl_custom_login_redirect_options'], 'custom_page', 'true');
            }
            ?> /> <label for='lsl_custom_login_redirect_custom'><?php esc_attr_e('Custom page', LSL_TEXT_DOMAIN); ?></label><br />

            <div class='lsl-custom-login-redirect-link' <?php
            if (isset($options['lsl_custom_login_redirect_options'])) {
                if ($options['lsl_custom_login_redirect_options'] == 'custom_page') {
                    ?> style='display: block' <?php } else { ?> style='display:none' <?php
                     }
                 }
                 ?>>
                <p class='lsl-title-text-field'>
                    <span><?php esc_attr_e('Login redirect page:', LSL_TEXT_DOMAIN); ?></span> <input type='text' name='lsl_custom_login_redirect_link' id='lsl-custom-login-redirect-link' value='<?php
                    if (isset($options['lsl_custom_login_redirect_link']) && $options['lsl_custom_login_redirect_link'] != '') {
                        echo $options['lsl_custom_login_redirect_link'];
                    }
                    ?>' />
                </p>
                <div class='lsl-info'>
                    <span class='lsl-info-note'><?php esc_attr_e('Note:', LSL_TEXT_DOMAIN); ?></span> <br />
                    <span class='lsl-info-content'><?php esc_attr_e('Please set this value if you want to redirect the user to the custom page url(full url). If this field is not set they will be redirected back to home page.', LSL_TEXT_DOMAIN); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-user-avatar-settings'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-user-avatar"><i class="fa fa-user-circle-o " aria-hidden="true"></i></span> <?php esc_attr_e('User Avatar', LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <input type='radio' id='lsl_user_avatar_default' class='lsl_user_avatar_options' name='lsl_user_avatar_options' value='default' <?php
            if (isset($options['lsl_user_avatar_options'])) {
                checked($options['lsl_user_avatar_options'], 'default', 'true');
            }
            ?> /> <label for='lsl_user_avatar_default'><?php esc_attr_e('Use wordpress provided default avatar.', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <input type='radio' id='lsl_user_avatar_social' class='lsl_user_avatar_options' name='lsl_user_avatar_options' value='social' <?php
            if (isset($options['lsl_user_avatar_options'])) {
                checked($options['lsl_user_avatar_options'], 'social', 'true');
            }
            ?> /> <label for='lsl_user_avatar_social'><?php esc_attr_e('Use the profile picture from social media where available.', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <div class='lsl-info'>
                <span class='lsl-info-note'><?php esc_attr_e('Note:', LSL_TEXT_DOMAIN); ?></span> <br />
                <span class='lsl-info-content'><?php esc_attr_e('Please choose the options from where you want your users avatar to be loaded from. If you choose default wordpress avatar it will use the gravatar profile image if user have gravatar profile assocated with their registered email address.', LSL_TEXT_DOMAIN); ?></span>
            </div>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-user-avatar-settings'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-user-login-control"><i class="fa fa-user-times" aria-hidden="true"></i></span> <?php esc_attr_e('User Login Control Settings', LSL_TEXT_DOMAIN); ?><span class="lsl-new-setting-span" ><?php esc_attr_e('New Setting', LSL_TEXT_DOMAIN); ?></span> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <input type='radio' id='lsl_user_avatar_default' class='lsl_user_avatar_options' name='lsl_user_login_allowed_type' value='yes' <?php
            if (isset($options['lsl_user_login_allowed_type'])) {
                checked($options['lsl_user_login_allowed_type'], 'yes', 'true');
            }
            ?> /> <label for='lsl_user_avatar_default'><?php esc_attr_e('Allow all users to log in', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <input type='radio' id='lsl_user_avatar_social' class='lsl_user_avatar_options' name='lsl_user_login_allowed_type' value='no' <?php
            if (isset($options['lsl_user_login_allowed_type'])) {
                checked($options['lsl_user_login_allowed_type'], 'no', 'true');
            }
            ?> /> <label for='lsl_user_avatar_social'><?php esc_attr_e('Allow only registered users to log in', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <p class='lsl-each-login-short-text'>
                <span><?php esc_attr_e('Message for non registered user', LSL_TEXT_DOMAIN); ?></span> <input type='text' name='lsl_login_non_registered_info_text' id='lsl-login-non-registered-text' value='<?php
                if (isset($options['lsl_login_non_registered_info_text']) && $options['lsl_login_non_registered_info_text'] != '') {
                    echo esc_attr($options['lsl_login_non_registered_info_text']);
                }
                ?>' />
            </p>
            <div class='lsl-info'>
                <span class='lsl-info-note'><?php esc_attr_e('Note:', LSL_TEXT_DOMAIN); ?></span> <br />
                <span class='lsl-info-content'><?php esc_attr_e('Please select the options to choose user log-in privilege. You can set to only allow already registered user to login.', LSL_TEXT_DOMAIN); ?></span>
            </div>
            <p class='lsl-each-login-short-text'>
                <input type='checkbox' id='lsl_custom_username_allow_login_autoclose' class='lsl_custom_username_allow' name='lsl_disable_autoclose_login_window' value='disable' <?php
                if (isset($options['lsl_disable_autoclose_login_window'])) {
                    checked($options['lsl_disable_autoclose_login_window'], 'disable', 'true');
                }
                ?> /> <label for='lsl_custom_username_allow_login_autoclose'><?php esc_attr_e('Disable auto close of login window', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <p class='lsl-each-login-short-text'>
            <div class='lsl-info'>
                <span class='lsl-info-note'><?php esc_attr_e('Note:', LSL_TEXT_DOMAIN); ?></span> <br />
                <span class='lsl-info-content'><?php esc_attr_e('If not disabled, the popup window will close automatically after 5 second of display.', LSL_TEXT_DOMAIN); ?></span>
            </div>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-user-email-settings'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-reply-all"><i class="fa fa-reply-all " aria-hidden="true"></i></span> <?php esc_attr_e('Email Notification Settings', LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <input type='radio' id='lsl_send_email_notification_yes' class='lsl_send_email_notification_yes lsl_send_email_notification_options' name='lsl_send_email_notification_options' value='yes' <?php
            if (isset($options['lsl_send_email_notification_options'])) {
                checked($options['lsl_send_email_notification_options'], 'yes', 'true');
            }
            ?> /> <label for='lsl_send_email_notification_yes'><?php esc_attr_e('Send email notification to both user and site admin.', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <div class='lsl-email-format-settings' <?php
            if (isset($options['lsl_send_email_notification_options'])) {
                if ($options['lsl_send_email_notification_options'] == 'yes') {
                    ?> style='display: block' <?php } else { ?> style='display:none' <?php
                     }
                 }
                 ?>>

                <label for='lsl-sender-email-address'><?php esc_attr_e('Sender Email Address:', LSL_TEXT_DOMAIN); ?></label> <input type='text' name='lsl_email_sender_email' id='lsl-sender-email-address' value='<?php
                if (isset($options['lsl_email_sender_email']) && $options['lsl_email_sender_email'] != '') {
                    echo $options['lsl_email_sender_email'];
                }
                ?>' />
                <label for='lsl-email-body'>
                    <?php esc_attr_e('Email Body:', LSL_TEXT_DOMAIN); ?>
                </label>
                <?php
                if (isset($options['lsl_email_body']) && $options['lsl_email_body'] != '') {
                    $content = self:: output_converting_br($options['lsl_email_body']);
                }
                ?>
                <!-- </textarea> -->
                <?php wp_editor($content, 'lsl_email_body', $settings = array('textarea_name' => 'lsl_email_body', 'editor_class' => 'lsl-email-body', 'media_buttons' => false, 'editor_height' => 400)); ?>

                <div class='lsl-info'>
                    <span class='lsl-info-note'><?php esc_attr_e('Note:', LSL_TEXT_DOMAIN); ?></span> <br />
                    <span class='lsl-info-content'>
                        <?php esc_attr_e('Available parameters:', LSL_TEXT_DOMAIN); ?>
                        <ul>
                            <li>#blogname - <?php esc_attr_e('Display Blog name in the email.', LSL_TEXT_DOMAIN); ?></li>
                            <li>#username - <?php esc_attr_e('Display Username in the email..', LSL_TEXT_DOMAIN); ?></li>
                            <li>#password - <?php esc_attr_e('Display the user password in email. ( Please use this parameter for wordpress version 4.3.0 or older ).', LSL_TEXT_DOMAIN); ?></li>
                            <li>#password_set_link - <?php esc_attr_e('Display the password set link. ( Please use this parameter for wordpress version 4.3.1 or greater ).', LSL_TEXT_DOMAIN); ?></li>
                        </ul>
                        <p><?php esc_attr_e('Note: Please configure this email template as per you need using paramaters available', LSL_TEXT_DOMAIN); ?> </p>
                    </span>
                </div>
            </div>
            <br />
            <input type='radio' id='lsl_send_email_notification_no' class='lsl_send_email_notification_no lsl_send_email_notification_options' name='lsl_send_email_notification_options' value='no' <?php
            if (isset($options['lsl_send_email_notification_options'])) {
                checked($options['lsl_send_email_notification_options'], 'no', 'true');
            }
            ?> /> <label for='lsl_send_email_notification_no'><?php esc_attr_e('Do not send email notification to both user and site admin.', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <div class='lsl-info'>
                <span class='lsl-info-note'><?php esc_attr_e('Note:', LSL_TEXT_DOMAIN); ?></span> <br />
                <span class='lsl-info-content'><?php esc_attr_e('Here you can configure an options to send email notifications about user registration.', LSL_TEXT_DOMAIN); ?></span>
            </div>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-username-email-settings'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-user-rename"><i class="fa fa-id-badge" aria-hidden="true"></i></span> <?php esc_attr_e('Username and Email Rename Settings', LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <input type='checkbox' id='lsl_custom_username_allow' class='lsl_custom_username_allow' name='lsl_custom_username_allow' value='allow' <?php
            if (isset($options['lsl_custom_username_allow'])) {
                checked($options['lsl_custom_username_allow'], 'allow', 'true');
            }
            ?> /> <label for='lsl_custom_username_allow'><?php esc_attr_e('Allow user to change their username.', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <input type='checkbox' id='lsl_custom_email_allow' class='lsl_custom_email_allow' name='lsl_custom_email_allow' value='allow' <?php
            if (isset($options['lsl_custom_email_allow'])) {
                checked($options['lsl_custom_email_allow'], 'allow', 'true');
            }
            ?> /> <label for='lsl_custom_email_allow'><?php esc_attr_e('Allow user to change email address.', LSL_TEXT_DOMAIN); ?></label><br /><br />
            <div class='lsl-info'>
                <span class='lsl-info-note'><?php esc_attr_e('Note:', LSL_TEXT_DOMAIN); ?></span> <br />
                <span class='lsl-info-content'><?php esc_attr_e('Please enable these options if you want your user to change their username or email or both during social login.', LSL_TEXT_DOMAIN); ?></span>
            </div>
        </div>
    </div>
</div>

<div class='lsl-settings'>
    <div class='lsl-username-email-settings'>
        <div class="lsl-label"><span class="lsl-other-setting-icon-span lsl-other-setting-text-setting"><i class="fa fa-wrench" aria-hidden="true"></i></span> <?php esc_attr_e('Additional Settings', LSL_TEXT_DOMAIN); ?> <span class="lsl-new-setting-span" ><?php esc_attr_e('New Setting', LSL_TEXT_DOMAIN); ?></span><span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
        <div class='lsl_network_settings_wrapper' style='display:none'>
            <input type='checkbox' id='lsl_add_no_follow_to_login_link' class='lsl_custom_username_allow' name='lsl_add_no_follow_in_login_link' value='yes' <?php
                   if (isset($options['lsl_add_no_follow_in_login_link'])) {
                       checked($options['lsl_add_no_follow_in_login_link'], 'yes', 'true');
                   }
                   ?> /> <label for='lsl_add_no_follow_to_login_link'><?php esc_attr_e('Add "No Follow" to the login link. For SEO reason', LSL_TEXT_DOMAIN); ?></label>
            </label><br /><br />
        </div>
    </div>
</div>