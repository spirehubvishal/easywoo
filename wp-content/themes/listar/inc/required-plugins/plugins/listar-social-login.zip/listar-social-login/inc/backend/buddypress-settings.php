<?php defined( 'ABSPATH' ) or die( "No script kiddies please!" ); ?>
<div class='lsl-settings'>
<div class="lsl-profile-mapping-wrapper">
	<div class="lsl-label"><?php esc_attr_e('XProfile Mapping Enable?', LSL_TEXT_DOMAIN ); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
	<div class='lsl_network_settings_wrapper lsl-profile-mapping' style='display:none'>
		<input type='radio' id='lsl-profile-mapping-enabled' class='lsl-profile-mapping-enabled lsl_profile_mapping_options' name='lsl_profile_mapping_options' value='yes' <?php if(isset($options['lsl_profile_mapping_options'])){ checked( $options['lsl_profile_mapping_options'], 'yes', 'true' ); } ?> /> <label for='lsl-profile-mapping-enabled'><?php esc_attr_e('Yes', LSL_TEXT_DOMAIN ); ?></label><br /><br />
		<input type='radio' id='lsl-profile-mapping-disabled' class='lsl-profile-mapping-disabled lsl_profile_mapping_options' name='lsl_profile_mapping_options' value='no' <?php if(isset($options['lsl_profile_mapping_options'])){ checked( $options['lsl_profile_mapping_options'], 'no', 'true' ); } ?> /> <label for='lsl-profile-mapping-disabled'><?php esc_attr_e('No', LSL_TEXT_DOMAIN ); ?></label><br /><br />
	</div>
</div>
</div>

<div class='lsl-settings lsl-profile-mapping-outer' style="<?php if(isset($options['lsl_profile_mapping_options']) && $options['lsl_profile_mapping_options'] == 'yes'){ ?> display:block; <?php }else{ ?> display:none; <?php } ?>">
<div class="lsl-profile-mapping-wrapper">
	<div class="lsl-label"><?php esc_attr_e('Fields Mapping', LSL_TEXT_DOMAIN ); ?> <span class='lsl_show_hide'><i class="fa fa-caret-down"></i></span> </div>
		

	<div class='lsl_network_settings_wrapper lsl-profile-mapping' style='display:none'>
		<div class='lsl-note'>
			Here you can map users profiles fields to the appropriate buddypress xprofile fields. The left column shows the available users profiles fields: These select boxes are called source fields. The right column shows the list of Buddypress profiles fields: Those are the destination fields. If you don't want to map a particular Buddypress field, then leave the source for that field blank.
		</div>

		<div class='xprofile-mapping-fields'>
			<?php

			$ha_profile_fields = array(
			);

				
			$ha_profile_fields = array(
										
									);

			if ( bp_has_profile() )
			{
				while ( bp_profile_groups() )
				{
					global $group;

					bp_the_profile_group();
					?>
						

						<table width="100%" border="0" cellpadding="5" cellspacing="2" style="border-top:1px solid #ccc;">
							<?php
								while ( bp_profile_fields() )
								{
									global $field;

									bp_the_profile_field();
									?>
										<tr>
											<td width="270" align="right" valign="top">
												<?php
													$map = isset( $options['lsl_settings_buddypress_xprofile_map'][$field->id] ) ? $options['lsl_settings_buddypress_xprofile_map'][$field->id] : 0;
													$can_map_it = true;

													if( ! in_array( $field->type, array( 'textarea', 'textbox', 'url', 'datebox', 'number' ) ) ){
														$can_map_it = false;
													}
												?>
												<select name="lsl_settings_buddypress_xprofile_map[<?php echo $field->id; ?>]" style="width:255px" id="bb_profile_mapping_selector_<?php echo $field->id; ?>" onChange="showMappingConfirm( <?php echo $field->id; ?> );" <?php if( ! $can_map_it ) echo "disabled"; ?>>
													<option value=""></option>
													<?php
														if( $can_map_it ){
															foreach( $ha_profile_fields as $item ){
															?>
																<option value="<?php echo $item['field']; ?>" <?php if( $item['field'] == $map ) echo "selected"; ?> ><?php echo $item['label']; ?></option>
															<?php
															}
														}
													?>
												</select>
											</td>
											<td valign="top" align="center" width="50">
												<!-- <img src="<?php echo $assets_base_url; ?>arr_right.png" /> -->
											</td>
											<td valign="top">
												<strong><?php echo $field->name; ?></strong>
												<?php
													if( ! $can_map_it ){
													?>
														<p class="description">

														</p>
													<?php
													}
													else{
													?>
														<?php
															foreach( $ha_profile_fields as $item ){
														?>
															<p class="description bb_profile_mapping_confirm_<?php echo $field->id; ?>" style="margin-left:0;<?php if( $item['field'] != $map ) echo "display:none;"; ?>" id="bb_profile_mapping_confirm_<?php echo $field->id; ?>_<?php echo $item['field']; ?>">

																<br />
																<em><b><?php echo $item['label']; ?>:</b> <?php echo $item['description']; ?>.</em>
															</p>
														<?php
															}
														?>
													<?php
													}
												?>
											</td>
										</tr>
									<?php
								}
							?>
						</table>
					<?php
				}
			}
		?>
		</div>
	</div>
</div>
</div>

