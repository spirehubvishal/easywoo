=== Listar Social Login ===
Contributors: Theme Server
Requires at least: 4.7.0
Tested up to: 6.4
Stable tag: 1.2.1
License: GNU General Public License v3.0

This plugin provides some of the functionality for the Listar theme: allows visitors to login with their social networks.

= Documentation =

Install and activate the plugin. Go to Listar Social Login and configure access keys for every social network API. More details on documentation for Listar Directory theme.

= Support Policy =

Please contact https://themeforest.net/user/webdesigntrade/ for technical support regarding the plugin.

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Other Notes ==

== Changelog ==

= 1.1: October 18, 2021 =

> Prefixed Classes for better compatibility with third party plugins that make use of the same Google API:

- Google_Utils_URITemplate
- Google_Client
- Google_Http_MediaFileUpload
- Google_Service_Resource
- Google_Exception
- Google_Model
- Google_Http_REST
- Google_Http_Batch
- Google_Collection
- Google_Service_Exception
- Google_Service

= 1.0: March 17, 2020 =

Initial release
