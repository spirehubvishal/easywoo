<div class='network-settings'>
    <?php
    if (isset($options['network_ordering']) && !empty($options['network_ordering'])) {
        foreach ($options['network_ordering'] as $key => $value):
            ?>
            <?php
            switch ($value) {
                case 'facebook':
                    ?>
                    <div class='lsl-settings lsl-facebook-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_facebook_settings']['lsl_facebook_enable']) && $options['lsl_facebook_settings']['lsl_facebook_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-facebook-square"></i></span> <?php esc_attr_e("Facebook", LSL_TEXT_DOMAIN); ?><span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'>
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type='hidden' name='network_ordering[]' value='facebook' />
                                <input type="checkbox" id='lsl-facbook-enable' value='enable' name='lsl_facebook_settings[lsl_facebook_enable]' <?php checked('enable', $options['lsl_facebook_settings']['lsl_facebook_enable']); ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('App ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-facebook-app-id' name='lsl_facebook_settings[lsl_facebook_app_id]' value='<?php
                                if (isset($options['lsl_facebook_settings']['lsl_facebook_app_id'])) {
                                    echo $options['lsl_facebook_settings']['lsl_facebook_app_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('App Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-facebook-app-secret' name='lsl_facebook_settings[lsl_facebook_app_secret]' value='<?php
                                if (isset($options['lsl_facebook_settings']['lsl_facebook_app_secret'])) {
                                    echo $options['lsl_facebook_settings']['lsl_facebook_app_secret'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-fb-profile-image-size'>
                                <label><?php esc_attr_e('Profile picture image size', LSL_TEXT_DOMAIN); ?></label><br />
                                <label for='lsl-fb-profile-image-width'><?php esc_attr_e('Width:', LSL_TEXT_DOMAIN); ?></label>  <input type='number' name='lsl_facebook_settings[lsl_profile_image_width]' id='lsl-fb-profile-image-width' value='<?php
                                if (isset($options['lsl_facebook_settings']['lsl_profile_image_width'])) {
                                    echo $options['lsl_facebook_settings']['lsl_profile_image_width'];
                                }
                                ?>' style="width: 60px;" /> px
                                <br />
                                <label for='lsl-fb-profile-image-height'><?php esc_attr_e('Height:', LSL_TEXT_DOMAIN); ?></label> <input type='number' name='lsl_facebook_settings[lsl_profile_image_height]' id='lsl-fb-profile-image-height' value='<?php
                                if (isset($options['lsl_facebook_settings']['lsl_profile_image_height'])) {
                                    echo $options['lsl_facebook_settings']['lsl_profile_image_height'];
                                }
                                ?>' style="width: 60px;" /> px
                            </div>
                        </div>
                    </div>
                    <?php break; ?>

                <?php case 'twitter': ?>
                    <div class='lsl-settings lsl-twitter-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_twitter_settings']['lsl_twitter_enable']) && $options['lsl_twitter_settings']['lsl_twitter_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'> <span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>-square"></i></span> <?php esc_attr_e("Twitter", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-twitter-enable' value='enable' name='lsl_twitter_settings[lsl_twitter_enable]' <?php checked('enable', $options['lsl_twitter_settings']['lsl_twitter_enable']); ?>  />
                                <div class="lsl-check round"></div>
                            </div>

                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Consumer Key (API Key):', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-twitter-app-id' name='lsl_twitter_settings[lsl_twitter_api_key]' value='<?php
                                if (isset($options['lsl_twitter_settings']['lsl_twitter_api_key'])) {
                                    echo $options['lsl_twitter_settings']['lsl_twitter_api_key'];
                                }
                                ?>' />
                            </div>

                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Consumer Secret (API Secret):', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-twitter-app-secret' name='lsl_twitter_settings[lsl_twitter_api_secret]' value='<?php
                                if (isset($options['lsl_twitter_settings']['lsl_twitter_api_secret'])) {
                                    echo $options['lsl_twitter_settings']['lsl_twitter_api_secret'];
                                }
                                ?>' />
                            </div>

                            <input type='hidden' name='network_ordering[]' value='twitter' />
                            
                        </div>
                    </div>
                    <?php
                    break;

                case 'google':
                    ?>
                    <div class='lsl-settings lsl-google-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>-plus"></i></span> <?php esc_attr_e("Google", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-google-enable' value='enable' name='lsl_google_settings[lsl_google_enable]' <?php checked('enable', $options['lsl_google_settings']['lsl_google_enable']); ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-google-client-id' name='lsl_google_settings[lsl_google_client_id]' value='<?php
                                if (isset($options['lsl_google_settings']['lsl_google_client_id'])) {
                                    echo $options['lsl_google_settings']['lsl_google_client_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-google-client-secret' name='lsl_google_settings[lsl_google_client_secret]' value='<?php
                                if (isset($options['lsl_google_settings']['lsl_google_client_secret'])) {
                                    echo $options['lsl_google_settings']['lsl_google_client_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='google' />
                           
                        </div>	
                    </div>
                    <?php break; ?>

                <?php case 'linkedin': ?>
                    <div class='lsl-settings lsl-linkedin-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'> <span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>-square"></i></span> <?php esc_attr_e("LinkedIn", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-linkedin-enable' value='enable' name='lsl_linkedin_settings[lsl_linkedin_enable]' <?php checked('enable', $options['lsl_linkedin_settings']['lsl_linkedin_enable']); ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-linkedin-client-id' name='lsl_linkedin_settings[lsl_linkedin_client_id]' value='<?php
                                if (isset($options['lsl_linkedin_settings']['lsl_linkedin_client_id'])) {
                                    echo $options['lsl_linkedin_settings']['lsl_linkedin_client_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-linkedin-client-secret' name='lsl_linkedin_settings[lsl_linkedin_client_secret]' value='<?php
                                if (isset($options['lsl_linkedin_settings']['lsl_linkedin_client_secret'])) {
                                    echo $options['lsl_linkedin_settings']['lsl_linkedin_client_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='linkedin' />
                            
                        </div>
                    </div>
                    <?php break; ?>


                <?php case 'instagram': ?>
                    <div class='lsl-settings lsl-instagram-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>"></i></span> <?php esc_attr_e("Instagram", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'>
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-instagram-enable' value='enable' name='lsl_instagram_settings[lsl_instagram_enable]' <?php checked('enable', $options['lsl_instagram_settings']['lsl_instagram_enable']); ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-instagram-api_key' name='lsl_instagram_settings[lsl_instagram_api_key]' value='<?php
                                if (isset($options['lsl_instagram_settings']['lsl_instagram_api_key'])) {
                                    echo $options['lsl_instagram_settings']['lsl_instagram_api_key'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-instagram-api-secret' name='lsl_instagram_settings[lsl_instagram_api_secret]' value='<?php
                                if (isset($options['lsl_instagram_settings']['lsl_instagram_api_secret'])) {
                                    echo $options['lsl_instagram_settings']['lsl_instagram_api_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='instagram' />
                            
                        </div>
                    </div>
                    <?php break; ?>

                <?php case 'foursquare': ?>
                    <div class='lsl-settings lsl-foursquare-settings'>
                        <!-- foursquare Settings -->
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>"></i></span> <?php esc_attr_e("Foursquare", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'>
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-foursquare-enable' value='enable' name='lsl_foursquare_settings[lsl_foursquare_enable]' <?php checked('enable', $options['lsl_foursquare_settings']['lsl_foursquare_enable']); ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-foursquare-client-id' name='lsl_foursquare_settings[lsl_foursquare_client_id]' value='<?php
                                if (isset($options['lsl_foursquare_settings']['lsl_foursquare_client_id'])) {
                                    echo $options['lsl_foursquare_settings']['lsl_foursquare_client_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-foursquare-client-secret' name='lsl_foursquare_settings[lsl_foursquare_client_secret]' value='<?php
                                if (isset($options['lsl_foursquare_settings']['lsl_foursquare_client_secret'])) {
                                    echo $options['lsl_foursquare_settings']['lsl_foursquare_client_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='foursquare' />
                            
                        </div>
                    </div>
                    <?php break; ?>

                <?php case 'wordpress': ?>
                    <div class='lsl-settings lsl-wordpress-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>"></i></span> <?php esc_attr_e("WordPress", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-wordpress-enable' value='enable' name='lsl_wordpress_settings[lsl_wordpress_enable]' <?php checked('enable', $options['lsl_wordpress_settings']['lsl_wordpress_enable']); ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-wordpress-client-id' name='lsl_wordpress_settings[lsl_wordpress_client_id]' value='<?php
                                if (isset($options['lsl_wordpress_settings']['lsl_wordpress_client_id'])) {
                                    echo $options['lsl_wordpress_settings']['lsl_wordpress_client_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-wordpress-client-secret' name='lsl_wordpress_settings[lsl_wordpress_client_secret]' value='<?php
                                if (isset($options['lsl_wordpress_settings']['lsl_wordpress_client_secret'])) {
                                    echo $options['lsl_wordpress_settings']['lsl_wordpress_client_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='wordpress' />
                            
                        </div>
                    </div>
                    <?php break; ?>
                <?php case 'vk': ?>
                    <div class='lsl-settings lsl-vk-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>"></i></span> <?php esc_attr_e("VKontakte", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-vk-enable' value='enable' name='lsl_vk_settings[lsl_vk_enable]' <?php checked('enable', $options['lsl_vk_settings']['lsl_vk_enable']); ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('App ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-vk-app-id' name='lsl_vk_settings[lsl_vk_app_id]' value='<?php
                                if (isset($options['lsl_vk_settings']['lsl_vk_app_id'])) {
                                    echo $options['lsl_vk_settings']['lsl_vk_app_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Secure Key:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-vk-secure_key' name='lsl_vk_settings[lsl_vk_secure_key]' value='<?php
                                if (isset($options['lsl_vk_settings']['lsl_vk_secure_key'])) {
                                    echo $options['lsl_vk_settings']['lsl_vk_secure_key'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='vk' />
                        </div>
                    </div>
                    <?php break; ?>

                <?php case 'buffer': ?>
                    <div class='lsl-settings lsl-buffer-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>"></i></span> <?php esc_attr_e("Buffer", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-buffer-enable' value='enable' name='lsl_buffer_settings[lsl_buffer_enable]' <?php checked('enable', $options['lsl_buffer_settings']['lsl_buffer_enable']); ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-buffer-client-id' name='lsl_buffer_settings[lsl_buffer_client_id]' value='<?php
                                if (isset($options['lsl_buffer_settings']['lsl_buffer_client_id'])) {
                                    echo $options['lsl_buffer_settings']['lsl_buffer_client_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-buffer-client-secret' name='lsl_buffer_settings[lsl_buffer_client_secret]' value='<?php
                                if (isset($options['lsl_buffer_settings']['lsl_buffer_client_secret'])) {
                                    echo $options['lsl_buffer_settings']['lsl_buffer_client_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='buffer' />
                        </div>
                    </div>
                    <?php break; ?>
                <?php case 'tumblr': ?>
                    <div class='lsl-settings lsl-buffer-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>"></i></span> <?php esc_attr_e("Tumblr", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><span class="lsl-new-setting-span" ><?php esc_attr_e('New Setting', LSL_TEXT_DOMAIN); ?></span><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-<?php echo $value; ?>-enable' value='enable' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_enable]' <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'checked' : ''; ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-buffer-client-id' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_client_id]' value='<?php
                                if (isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_id'])) {
                                    echo $options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-buffer-client-secret' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_client_secret]' value='<?php
                                if (isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_secret'])) {
                                    echo $options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='tumblr' />
                        </div>
                    </div>
                    <?php break; ?>
                <?php case 'reddit': ?>
                    <div class='lsl-settings lsl-buffer-settings'>
                        <!-- Buffer Settings -->
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>"></i></span> <?php esc_attr_e("Reddit", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><span class="lsl-new-setting-span" ><?php esc_attr_e('New Setting', LSL_TEXT_DOMAIN); ?></span><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-<?php echo $value; ?>-enable' value='enable' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_enable]' <?php echo $value; ?>_enable]' <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'checked' : ''; ?>  />
                                       <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-<?php echo $value; ?>-client-id' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_client_id]' value='<?php
                                if (isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_id'])) {
                                    echo $options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-<?php echo $value; ?>-client-secret' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_client_secret]' value='<?php
                                if (isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_secret'])) {
                                    echo $options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='reddit' />
                        </div>
                    </div>
                    <?php break; ?>
                <?php case 'yahoo': ?>
                    <div class='lsl-settings lsl-buffer-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>"></i></span> <?php esc_attr_e("Yahoo", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><span class="lsl-new-setting-span" ><?php esc_attr_e('New Setting', LSL_TEXT_DOMAIN); ?></span><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-<?php echo $value; ?>-enable' value='enable' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_enable]' <?php echo $value; ?>_enable]' <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'checked' : ''; ?>  />
                                       <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-<?php echo $value; ?>-client-id' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_client_id]' value='<?php
                                if (isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_id'])) {
                                    echo $options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-<?php echo $value; ?>-client-secret' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_client_secret]' value='<?php
                                if (isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_secret'])) {
                                    echo $options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='<?php echo $value; ?>' />
                        </div>
                    </div>
                    <?php break; ?>
                <?php case 'weibo': ?>
                    <div class='lsl-settings lsl-buffer-settings'>
                        <div class='lsl-label <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'lsl-active-network' : ''; ?>'><span class="social-link-display-icon social-link-display-icon-<?php echo $value; ?>"><i class="fa fa-<?php echo $value; ?>"></i></span> <?php esc_attr_e("Weibo", LSL_TEXT_DOMAIN); ?> <span class='lsl_show_hide' id='lsl_show_hide_<?php echo $value; ?>'><span class="lsl-new-setting-span" ><?php esc_attr_e('New Setting', LSL_TEXT_DOMAIN); ?></span><i class="fa fa-caret-down"></i></span> </div>
                        <div class='lsl_network_settings_wrapper' id='lsl_network_settings_<?php echo $value; ?>' style='display:none'>
                            <div class='lsl-enable-disable lsl-even-class'> 
                                <label><?php esc_attr_e('Enable?', LSL_TEXT_DOMAIN); ?></label>
                                <input type="checkbox" id='lsl-<?php echo $value; ?>-enable' value='enable' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_enable]' <?php echo isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable']) && $options['lsl_' . $value . '_settings']['lsl_' . $value . '_enable'] == 'enable' ? 'checked' : ''; ?>  />
                                <div class="lsl-check round"></div>
                            </div>
                            <div class='lsl-app-id-wrapper lsl-odd-class'>
                                <label><?php esc_attr_e('Client ID:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-<?php echo $value; ?>-client-id' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_client_id]' value='<?php
                                if (isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_id'])) {
                                    echo $options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_id'];
                                }
                                ?>' />
                            </div>
                            <div class='lsl-app-secret-wrapper lsl-even-class'>
                                <label><?php esc_attr_e('Client Secret:', LSL_TEXT_DOMAIN); ?></label><input type='text' id='lsl-<?php echo $value; ?>-client-secret' name='lsl_<?php echo $value; ?>_settings[lsl_<?php echo $value; ?>_client_secret]' value='<?php
                                if (isset($options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_secret'])) {
                                    echo $options['lsl_' . $value . '_settings']['lsl_' . $value . '_client_secret'];
                                }
                                ?>' />
                            </div>
                            <input type='hidden' name='network_ordering[]' value='<?php echo $value; ?>' />
                        </div>
                    </div>
                    <?php break; ?>
                <?php
                default:
                    ?>
                    <div class="lsl-label lsl-no-setting-social-notice">
                        <p><?php echo __('No fields settings for ' . $value . ' found', LSL_TEXT_DOMAIN) . '<br/>'; ?></p>
                    </div>
                    <?php
                    break;
            }
            ?>
            <?php
        endforeach;
    } else {
        ?>
        <div class='lsl-settings lsl-no-setting-table-notice'>
            <div class='lsl-label'>
                <?php echo __('No table found. Please try "Restore Default Setting" or "Reactivating the plugin."', LSL_TEXT_DOMAIN); ?>
            </div>
        </div>
    <?php }
    ?>
</div>