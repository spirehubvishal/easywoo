<?php
defined('ABSPATH') or die("No script kiddies please!");
$current_url = LSL_Class:: curlPageURL();
$options = get_option(LSL_SETTINGS);

if (isset($options['lsl_custom_login_redirect_options']) && $options['lsl_custom_login_redirect_options'] != '') {
    if ($options['lsl_custom_login_redirect_options'] == 'home') {
        $user_login_url = network_site_url();
    } else if ($options['lsl_custom_login_redirect_options'] == 'current_page') {
        $user_login_url = $current_url;
    } else if ($options['lsl_custom_login_redirect_options'] == 'custom_page') {
        if ($options['lsl_custom_login_redirect_link'] != '') {
            $login_page = $options['lsl_custom_login_redirect_link'];
            $user_login_url = $login_page;
        } else {
            $user_login_url = network_site_url();
        }
    }
} else {
    $user_login_url = network_site_url();
}

// $redirect_to = isset( $_REQUEST['redirect_to'] ) ? $_REQUEST['redirect_to'] : '';

$encoded_url = urlencode($user_login_url);
?>

<div class='<?php if (is_rtl()) { ?> lsl-rtl-wrap <?php } ?> lsl-login-networks theme-<?php echo $options['lsl_icon_theme']; ?> clearfix'>
    <span class='lsl-login-new-text'><?php echo $options['lsl_title_text_field']; ?></span>
    <?php if (isset($_SESSION['lsl_login_error_flag']) && $_SESSION['lsl_login_error_flag'] == '1') { //if( isset($_REQUEST['error']) || isset($_REQUEST['denied']) ){  ?>
        <div class='lsl-error'>
            <?php
            if (isset($options['lsl_login_error_message']) && $options['lsl_login_error_message'] != '') {
                echo $options['lsl_login_error_message'];
            } else {
                _e('You have Access Denied. Please authorize the app to login.', LSL_TEXT_DOMAIN);
            }
            ?>
        </div>
        <?php
        unset($_SESSION['lsl_login_error_flag']);
    }
    ?>

    <div class='social-networks'>
        <?php foreach ($options['network_ordering'] as $key => $value): ?>
            <?php if (isset($options["lsl_{$value}_settings"]["lsl_{$value}_enable"]) && $options["lsl_{$value}_settings"]["lsl_{$value}_enable"] === 'enable') { ?>
                <?php
                if ($encoded_url) {
                    $state = "&state=" . base64_encode("redirect_to=$encoded_url");
                } else {
                    $state = '';
                }
                ?>
                <?php $link = wp_login_url(). "?lsl_login_id=$value" . "_login" . $state; ?>
                <a href='javascript:void(0);' <?php echo isset($options['lsl_add_no_follow_in_login_link']) && $options['lsl_add_no_follow_in_login_link'] == 'yes' ? 'rel="nofollow"' : ''; ?> onclick="lsl_open_in_popup_window(event, '<?php echo $link; ?>');" title='<?php
                if (isset($options['lsl_each_link_title_attribute']) && $options['lsl_each_link_title_attribute'] != '') {
                    echo $options['lsl_each_link_title_attribute'];
                    } else {
                        _e('Login with', LSL_TEXT_DOMAIN);
                        } echo ' ' . $value;
                        ?>' >
                        <div class="lsl-icon-block lsl-icon-<?php echo $value; ?> <?php
                        if ($value == 'buffer') {
                            echo "buffer";
                        }
                        ?> clearfix">
                        <i class="fa fa-<?php echo $value; ?>"></i>
                        <?php echo isset($options['lsl_icon_theme']) && $options['lsl_icon_theme'] == '20' ? '<span class="login-longshort-text-wrapper">' : ''; ?>
                        <?php echo isset($options['lsl_icon_theme']) && $options['lsl_icon_theme'] == '20' ? '<span class="lsl-social-media-text">' . $value . '</span>' : ''; ?>
                        <span class="lsl-login-text"><?php
                        if (isset($options['lsl_login_short_text']) && !empty($options['lsl_login_short_text'])) {
                            echo __(esc_attr($options['lsl_login_short_text']), LSL_TEXT_DOMAIN);
                        } else {
                            _e('Login', LSL_TEXT_DOMAIN);
                        }
                        ?></span>
                        <span class="lsl-long-login-text" <?php echo isset($options['lsl_icon_theme']) && $options['lsl_icon_theme'] == '30' ? 'data-hover="' . $value . '"' : ''; ?>><?php
                        if ((isset($options['lsl_showhide_title_attr']) && $options['lsl_showhide_title_attr'] == 'show') || !isset($options['lsl_showhide_title_attr'])) {
                            if (isset($options['lsl_login_with_long_text']) && $options['lsl_login_with_long_text'] != '') {
                                echo __(esc_attr($options['lsl_login_with_long_text']), LSL_TEXT_DOMAIN);
                            } else {
                                _e('Login with', LSL_TEXT_DOMAIN);
                            }
                            ?>
                        <?php } ?>
                        <?php echo ' ' . $value; ?></span>
                        <?php echo isset($options['lsl_icon_theme']) && $options['lsl_icon_theme'] == '20' ? '</span>' : ''; ?>
                        <?php if (isset($options['lsl_icon_theme']) && $options['lsl_icon_theme'] == '28') { ?>
                            <span class="line -right"></span><span class="line -top"></span><span class="line -left"></span><span class="line -bottom"></span>
                        <?php } ?>
                    </div>
                </a>
            <?php } ?>
        <?php endforeach; ?>
    </div>
</div>