<?php

defined('ABSPATH') or die('No script kiddies please!');
$lsl_settings = array();

$social_networks = array(
    0 => 'facebook',
    1 => 'twitter',
    2 => 'google',
    3 => 'linkedin',
    4 => 'instagram',
    5 => 'vk',
    6 => 'foursquare',
    7 => 'wordpress',
    8 => 'buffer'
);
$lsl_settings['network_ordering'] = $social_networks;

/*
 * New Social Network array to add >> Since version 2.0.0
 */
$social_networks_new_array = array(
    0 => 'tumblr',
    1 => 'reddit',
    2 => 'yahoo',
        //3 => 'weibo'
); //0 => 'tumblr', 1 => 'reddit');
$lsl_settings['network_ordering'] = array_merge($social_networks, $social_networks_new_array);

/*
 * Different parameter settings
 */

//Facebook Settings
$facebook_parameters = array(
    'lsl_facebook_enable' => '0',
    'lsl_facebook_app_id' => '',
    'lsl_facebook_app_secret' => '',
    'lsl_profile_image_width' => '480',
    'lsl_profile_image_height' => '480'
);
$lsl_settings['lsl_facebook_settings'] = $facebook_parameters;

//twitter settings
$twitter_parameters = array(
    'lsl_twitter_enable' => '0',
    'lsl_twitter_api_key' => '',
    'lsl_twitter_api_secret' => ''
);
$lsl_settings['lsl_twitter_settings'] = $twitter_parameters;

//google settings
$google_parameters = array(
    'lsl_google_enable' => '0',
    'lsl_google_client_id' => '',
    'lsl_google_client_secret' => ''
);
$lsl_settings['lsl_google_settings'] = $google_parameters;

//linkedin settings
$linkedin_parameters = array(
    'lsl_linkedin_enable' => '0',
    'lsl_linkedin_client_id' => '',
    'lsl_linkedin_client_secret' => ''
);
$lsl_settings['lsl_linkedin_settings'] = $linkedin_parameters;

//Instagram settings
$instagram_parameters = array(
    'lsl_instagram_enable' => '0',
    'lsl_instagram_api_key' => '',
    'lsl_instagram_api_secret' => ''
);
$lsl_settings['lsl_instagram_settings'] = $instagram_parameters;

//vk settings
$vk_parameters = array(
    'lsl_vk_enable' => '0',
    'lsl_vk_app_id' => '',
    'lsl_vk_secure_key' => ''
);
$lsl_settings['lsl_vk_settings'] = $vk_parameters;

//Foursquare settings
$foursquare_parameters = array(
    'lsl_foursquare_enable' => '0',
    'lsl_foursquare_client_id' => '',
    'lsl_foursquare_client_secret' => ''
);
$lsl_settings['lsl_foursquare_settings'] = $foursquare_parameters;

//Wordpress settings
$wordpress_parameters = array(
    'lsl_wordpress_enable' => '0',
    'lsl_wordpress_client_id' => '',
    'lsl_wordpress_client_secret' => ''
);
$lsl_settings['lsl_wordpress_settings'] = $wordpress_parameters;

//Buffer settings
$buffer_parameters = array(
    'lsl_buffer_enable' => '0',
    'lsl_buffer_client_id' => '',
    'lsl_buffer_client_secret' => ''
);
$lsl_settings['lsl_buffer_settings'] = $buffer_parameters;

//Reddit settings
$reddit_parameters = array(
    'lsl_reddit_enable' => '0',
    'lsl_reddit_client_id' => '',
    'lsl_reddit_client_secret' => ''
);
$lsl_settings['lsl_reddit_settings'] = $reddit_parameters;

//Tumblr Settings
$tumblr_parameters = array(
    'lsl_tumblr_enable' => '0',
    'lsl_tumblr_client_id' => '',
    'lsl_tumblr_client_secret' => ''
);
$lsl_settings['lsl_tumblr_settings'] = $tumblr_parameters;

//Yahoo settings
$yahoo_parameters = array(
    'lsl_yahoo_enable' => '0',
    'lsl_yahoo_client_id' => '',
    'lsl_yahoo_client_secret' => ''
);
$lsl_settings['lsl_yahoo_settings'] = $yahoo_parameters;

//Weibo settings
$weibo_parameters = array(
    'lsl_weibo_enable' => '0',
    'lsl_weibo_client_id' => '',
    'lsl_weibo_client_secret' => ''
);
$lsl_settings['lsl_weibo_settings'] = $weibo_parameters;

$lsl_settings['lsl_enable_disable_plugin'] = 'no';
$lsl_settings['lsl_enable_disable_buddypress'] = 'no';
$lsl_settings['lsl_enable_disable_woocommerce'] = 'no';

// for easy digital download settings
$lsl_settings['lsl_enable_disable_edd_login_shortcode'] = 'no';

$lsl_settings['lsl_enable_disable_edd_register_shortcode'] = 'no';

$lsl_settings['lsl_enable_disable_edd_checkout'] = 'no';
// for easy digital download settings ends

$display_options = array('login_form', 'register_form', 'comment_form');
$lsl_settings['lsl_display_options'] = $display_options;

$lsl_settings ['lsl_user_role'] = 'subscriber';

$lsl_settings['lsl_icon_theme'] = '1';

$lsl_settings['lsl_title_text_field'] = 'Social connect:';

$lsl_settings['lsl_login_short_text'] = '';

$lsl_settings['lsl_login_with_long_text'] = '';

$lsl_settings['lsl_each_link_title_attribute'] = '';

$lsl_settings['lsl_login_error_message'] = '';

$lsl_settings['lsl_custom_logout_redirect_options'] = 'home';
$lsl_settings['lsl_custom_logout_redirect_link'] = '';

$lsl_settings['lsl_custom_login_redirect_options'] = 'home';
$lsl_settings['lsl_custom_login_redirect_link'] = '';

$lsl_settings['lsl_user_avatar_options'] = 'default';
$lsl_settings['lsl_send_email_notification_options'] = 'yes';

// $lsl_settings['lsl_email_sender_name'] = '';
$lsl_settings['lsl_email_sender_email'] = '';
$lsl_settings['lsl_email_body'] = "Hello there,
\n
Welcome to #blogname
\n
Here's your log details:
Username: #username
To set your password, visit the following link: <a href='#password_set_link'>Link</a>
\n
Thank You!";

$lsl_settings['lsl_custom_username_allow'] = '';
$lsl_settings['lsl_custom_email_allow'] = '';
$lsl_settings['lsl_profile_mapping_options'] = 'no';

//Since version 2.0.0
$lsl_settings['lsl_user_login_allowed_type'] = 'yes';
$lsl_settings['lsl_login_non_registered_info_text'] = 'Sorry. Only registered user can log in. This window will close automatically after 5 seconds.';

update_option(LSL_SETTINGS, $lsl_settings);
