<div class="wrap"><div class='lsl-outer-wrapper'>
        <?php include(LSL_PLUGIN_DIR . 'inc/backend/header.php'); ?>
        <div class="clear"></div>
        <?php
        $options = get_option(LSL_SETTINGS);
        if (isset($_SESSION['lsl_message'])) {
            ?>
            <div class="lsl-message">
                <p><?php
                    echo $_SESSION['lsl_message'];
                    unset($_SESSION['lsl_message']);
                    ?></p>
            </div>
        <?php } ?>
        <div class='lsl-networks'>
            <div class='lsl-network-options'>
                <form method="post" action="<?php echo admin_url() . 'admin-post.php' ?>">
                    <input type="hidden" name="action" value="lsl_save_options"/>
                    <div class='wrap about-wrap clearfix'>
                        <h2 class='nav-tab-wrapper clearfix'>
                            <a href='javascript: void(0);' id='lsl-networks-settings' class='nav-tab nav-tab-active ' ><span><i class="fa fa-share-alt"></i></span> <?php esc_attr_e('Network settings', LSL_TEXT_DOMAIN) ?></a>
                            <a href='javascript: void(0);' id='lsl-theme-settings' class='nav-tab' ><span><i class="fa fa-cogs"></i></span> <?php esc_attr_e('Other settings', LSL_TEXT_DOMAIN) ?></a>
                            <?php if (function_exists('bp_has_profile')) { ?>
                                <a href='javascript: void(0);' id='lsl-buddypress-settings' class='nav-tab' ><span><i class="fa fa-user-friends"></i></span> <?php esc_attr_e('BuddyPress settings', LSL_TEXT_DOMAIN) ?></a>
                            <?php } ?>
                            <a href='javascript: void(0);' id='lsl-how-to-use' class='nav-tab' ><span><i class="fa fa-question-circle"></i></span> <?php esc_attr_e('How to use', LSL_TEXT_DOMAIN) ?></a>
                            <a href='javascript: void(0);' id='lsl-about' class='nav-tab' ><span><i class="fa fa-info"></i></span> <?php esc_attr_e('About', LSL_TEXT_DOMAIN) ?></a>
                            <a href='javascript: void(0);' id='lsl-more-wordpress-resources' class='nav-tab' ><span><i class="fa fa-wordpress"></i></span> <?php esc_attr_e('More WordPress Resources', LSL_TEXT_DOMAIN) ?></a>
                            </ul>
                    </div>
                    <div class='lsl-setting-tabs-wrapper'>
                        <div class='lsl-tab-contents' id='tab-lsl-networks-settings'>
                            <?php include(LSL_PLUGIN_DIR . 'inc/backend/networks-settings.php'); ?>
                        </div>

                        <div class='lsl-tab-contents' id='tab-lsl-theme-settings' style="display:none">
                            <?php include(LSL_PLUGIN_DIR . 'inc/backend/theme-settings.php'); ?>
                        </div>

                        <?php if (function_exists('bp_has_profile')) { ?>
                            <div class='lsl-tab-contents' id='tab-lsl-buddypress-settings' style="display:none">
                                <?php include(LSL_PLUGIN_DIR . 'inc/backend/buddypress-settings.php'); ?>
                            </div>
                        <?php } ?>

                        <!-- how to use section -->
                        <div class='lsl-tab-contents' id='tab-lsl-how-to-use' style="display:none">
                            <?php include(LSL_PLUGIN_DIR . 'inc/backend/how-to-use.php'); ?>
                        </div>

                        <!-- about section -->
                        <div class='lsl-tab-contents' id='tab-lsl-about' style="display:none">
                            <?php include(LSL_PLUGIN_DIR . 'inc/backend/about.php'); ?>
                        </div>
                        <div class='lsl-tab-contents' id='tab-lsl-more-wordpress-resources' style="display:none">
                            <?php include( LSL_PLUGIN_DIR . 'inc/backend/more-wordpress-resources.php' ); ?>
                        </div>
                        <!-- Save settings Button -->
                        <div class='lsl-save-settings'>
                            <?php wp_nonce_field('lsl_nonce_save_settings', 'lsl_settings_action'); ?>
                            <input type='submit' class='lsl-submit-settings primary-button' name='lsl_save_settings' value='<?php esc_attr_e('Save settings', LSL_TEXT_DOMAIN); ?>' />
                        </div>

                        <div class='lsl-restore-settings'>
                            <?php $nonce = wp_create_nonce('lsl-restore-default-settings-nonce'); ?>
                            <a href="<?php echo admin_url() . 'admin-post.php?action=lsl_restore_default_settings&_wpnonce=' . $nonce; ?>" onclick="return confirm('<?php esc_attr_e('Are you sure you want to restore default settings?', LSL_TEXT_DOMAIN); ?>')"><input type="button" value="Restore Default Settings" class="lsl-reset-button button primary-button"/></a>
                            <?php if (isset($options['network_ordering']) && !in_array('yahoo', $options['network_ordering'])) { ?>
                                <a href="<?php echo admin_url() . 'admin-post.php?action=lsl_add_new_network_array&_wpnonce=' . $nonce; ?>" onclick="return confirm('<?php esc_attr_e('Add New Social Login Sites? 3 new Social sites will be added. Since version >= 2.0.0.', LSL_TEXT_DOMAIN); ?>')"><input type="button" value="Insert New Social Login Sites" class="lsl-reset-button button primary-button"/></a>
                                <?php } ?>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>