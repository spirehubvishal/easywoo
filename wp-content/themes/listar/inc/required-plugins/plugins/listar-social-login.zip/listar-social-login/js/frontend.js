function lsl_open_in_popup_window(event, url){
    event.preventDefault();
    window.open(url, 'fdadas', 'toolbars=0,width=800,height=600,left=100,top=50,scrollbars=1,resizable=1');
    // parent.close();
}

jQuery(document).ready(function($){

	$('.show-lsl-container').on('click', function(e){
        e.preventDefault();
        $('.lsl-container').slideToggle();
    });

    $('.lsl-link-account-button').click(function(){
        $('.lsl-buttons-wrapper').hide();
        $('.lsl-login-form').show();
        $('.lsl-registration-wrapper').addClass('lsl-login-registration-form');
    });

    $('.lsl-create-account-button').click(function(){
        $('.lsl-buttons-wrapper').hide();
        $('.lsl-registration-form').show();
        $('.lsl-registration-wrapper').addClass('lsl-login-registration-form');
    });

    $('.lsl-back-button').click(function(){
        $('.lsl-buttons-wrapper').show();
        $('.lsl-login-form').hide();
        $('.lsl-registration-form').hide();
        $('.lsl-registration-wrapper').removeClass('lsl-login-registration-form');
    });


    $(':input[name="lsl_complete_registration"]').prop('disabled', true);
    $('#lsl-username-input').on( 'blur', function(e) {
        var $wrapper = $( this ).parent('.lsl-registration-form-wrapper');
        if( ! $wrapper.get(0) ) {
            $wrapper = create_wrapper( this );
        }
        
        $( '.lsl-name-info', $wrapper ).empty();//hhide the message
        //show loading icon
        $( '.lsl-loading', $wrapper ).css( {display:'block'} );
        var user_name = $( this ).val();
        var ajaxurl = lsl_ajax_object.ajax_url;
        $.post( ajaxurl, {
            action: 'lsl_check_username',
            cookie: encodeURIComponent(document.cookie),
            user_name: user_name
            },
            function( resp ) {
                if( resp && resp.code != undefined && resp.code == 'success' ) {
                        show_message( $wrapper, resp.message, 0 );
                        $(':input[name="lsl_complete_registration"]').prop('disabled', false);
                } else {
                    show_message( $wrapper, resp.message, 1 );
                    $(':input[name="lsl_complete_registration"]').prop('disabled', true);
                }

            },
            'json'

        );
    });//end of onblur
    
    function show_message( $wrapper, msg, is_error ) {//hide ajax loader
        
        $( '.lsl-name-info', $wrapper ).removeClass('lsl-available lsl-error');
        
        $( '.lsl-loading', $wrapper ).css( {display:'none'} );
        
        $( '.lsl-name-info', $wrapper ).html( msg );
      
        if( is_error ) {
            $( '.lsl-name-info', $wrapper ).addClass( 'lsl-error' );
        } else {
            $( '.lsl-name-info', $wrapper ).addClass( 'lsl-available' );
        }
    }

    function create_wrapper( element ) {
        var $wrapper = $( element ).parent('.lsl-registration-form-wrapper');
        
        if( ! $wrapper.get(0) ) {
            
            $( element ).wrap( "<div class='lsl-registration-form-wrapper'></div>" );
            
            $wrapper = $( element ).parent('.lsl-registration-form-wrapper');
            $wrapper.append( "<span class='lsl-loading' style='display:none'></span>" );
            $wrapper.append( "<span class='lsl-name-info'></span>" );
        }
        
        return $wrapper;
    }
});