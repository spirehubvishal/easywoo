<?php
// get_header(); // can be activated if needed
$options = get_option(LSL_SETTINGS);
if (isset($_SESSION['user_details'])) {
    //var_dump($_SESSION['user_details']);
    $user_object = isset($_SESSION['user_details']) ? $_SESSION['user_details'] : '';
    if (isset($_POST['lsl_complete_registration'])) {
        if (isset($_POST['lsl-email-input'])) {
            $email = sanitize_text_field($_POST['lsl-email-input']);
            if (LSL_Functions:: getUserByMail($email) == true) {
                $email_error = __('Hey! Your email already exist in our system. Please change email address to continue or you can link your account by going back.', LSL_TEXT_DOMAIN);
            }
        }

        if (isset($_POST['lsl-username-input'])) {
            $username = sanitize_text_field($_POST['lsl-username-input']);
            if (LSL_Functions:: getUserByUsername($username) == true) {
                $username_error = __('Username already exist.', LSL_TEXT_DOMAIN);
            }
        }

        if (isset($options['lsl_custom_username_allow']) && $options['lsl_custom_username_allow'] == 'allow') {
            $username = sanitize_text_field($_POST['lsl-username-input']);
        } else {
            $username = $user_object->username;
        }

        if (isset($options['lsl_custom_email_allow']) && $options['lsl_custom_email_allow'] == 'allow') {
            $email = sanitize_text_field($_POST['lsl-email-input']);
        } else {
            $email = $user_object->email;
        }
        if (!isset($email_error) && !isset($username_error)) {
            LSL_Functions::creatUser($username, $email);
            $row = LSL_Functions::getUserByMail($email);
            $id = $row->ID;

            $result = $user_object;
            $result->email = $email;
            unset($_SESSION['user_details']);
            $role = $options['lsl_user_role'];

            LSL_Functions:: UpdateUserMeta($id, $result, $role);
            LSL_Functions:: loginUser($id);
            exit();
        }

        if (isset($username_error) && isset($email_error))
            $message_string = $username_error . ' ' . $email_error;
        else if (isset($username_error))
            $message_string = $username_error;
        else if (isset($email_error))
            $message_string = $email_error;
    }

    if (isset($_POST['lsl_login_details_submit'])) {
        global $wpdb;
        $username = sanitize_user($_POST['login_username']);
        $password = sanitize_text_field($_POST['login_password']);
        $user = get_user_by('login', $username);
        if ($user && wp_check_password($password, $user->data->user_pass, $user->ID)) {
            //echo "That's it. Now you can get the user details from there";
            $id = $user->ID;
            $result = $user_object;
            unset($_SESSION['user_details']);
            $role = $options['lsl_user_role'];
            LSL_Functions:: link_user($id, $result);
            LSL_Functions:: loginUser($id);
            exit();
        } else {
            $error_message = __('Invalid Username or Password.', LSL_TEXT_DOMAIN);
        }
    }


    $user_object = isset($_SESSION['user_details']) ? $_SESSION['user_details'] : '';
    $username = LSL_Functions:: get_username($user_object->username);
    ?>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
    </head>
    <body>
        <div class='lsl-registration-wrapper'>
            <div class="lsl-login-wrap">
                <div class='lsl-social-profile-image'><img src='<?php echo $user_object->deuimage; ?>' alt='<?php echo $user_object->first_name; ?>' /></div>

                <div class='lsl-registration-info'>
                    <?php echo _e('Hi', LSL_TEXT_DOMAIN); ?> <span class='lsl-user_name'><?php echo $user_object->first_name; ?></span>,<p class="lsl-login-message">
                        <?php _e('You\'ve now successfully authorized your social profile account but you are still one step away for logging into website.', LSL_TEXT_DOMAIN); ?></p>
                </div>

                <div class='lsl-buttons-wrapper clearfix' style="<?php
                if (isset($_POST['lsl_complete_registration']) || isset($_POST['lsl_login_details_submit'])) {
                    echo "display:none";
                } else {
                    echo "display:block";
                }
                ?>" >
                    <div class='lsl-login-form-wrapper' >
                        <span class='lsl-have-account'><?php echo _e('Have an account?', LSL_TEXT_DOMAIN); ?></span>
                        <p><?php echo _e('Simply click the below button to link you social profile with existing account.', LSL_TEXT_DOMAIN); ?></p>
                        <button class='lsl-link-account-button'><?php echo _e('Link my account', LSL_TEXT_DOMAIN); ?></button>
                    </div>
                    <div class='lsl-register-form-wrapper'>
                        <span class='lsl-have-account'><?php echo _e('New to website?', LSL_TEXT_DOMAIN); ?></span>
                        <p><?php echo _e('Simply click the below button to do simple registration to our site.', LSL_TEXT_DOMAIN); ?></p>
                        <button class='lsl-create-account-button'><?php echo _e('Create my account', LSL_TEXT_DOMAIN); ?></button>
                    </div>
                </div>

                <div class='lsl-registration-form' style='<?php
                if (isset($_POST['lsl_complete_registration'])) {
                    echo "display:block";
                } else {
                    echo "display:none";
                }
                ?>'>
                    <div class='message-wrapper'> <?php
                        if (isset($message_string)) {
                            echo $message_string;
                        }
                        ?> </div>
                    <form action='' method='POST' class="clearfix">
                        <?php if (isset($options['lsl_custom_username_allow']) && $options['lsl_custom_username_allow'] == 'allow') { ?>
                            <div class='lsl-registration-form-wrapper' >
                                <label for='lsl-username-input' ><?php echo _e('Username:', LSL_TEXT_DOMAIN); ?></label>
                                <input type='text' name='lsl-username-input' value='<?php
                                if (isset($_POST['lsl-username-input'])) {
                                    echo $_POST['lsl-username-input'];
                                } else {
                                    echo $username;
                                }
                                ?>' id='lsl-username-input' required/>
                                <span class='lsl-loading' style='display:none'></span>
                                <span class='lsl-name-info'></span>

                            </div>
                            <div class='lsl-inline-info'><?php _e('Note: Your username can not be changed later, please make sure to create it.'); ?></div>
                        <?php } ?>

                        <?php if (isset($options['lsl_custom_email_allow']) && $options['lsl_custom_email_allow'] == 'allow') { ?>
                            <div class='lsl-registration-form-wrapper'><label for='lsl-email-input' ><?php echo _e('Email:', LSL_TEXT_DOMAIN); ?></label><input type='email' name='lsl-email-input' value='<?php
                                if (isset($_POST['lsl-email-input'])) {
                                    echo $_POST['lsl-email-input'];
                                } else {
                                    echo $user_object->email;
                                }
                                ?>' id='lsl-email-input' required /></div>
                                                                                                                                                               <?php } ?>
                        <div class="lsl-registration-field-wrapper">
                            <div class="lsl-registration-user-field lsl-submit-registration">
                                <input type='submit' name='lsl_complete_registration' id='lsl_complete_registration' value='<?php echo _e('Continue', LSL_TEXT_DOMAIN); ?>' />
                            </div>
                        </div>		<a href='javascript:void(0);'><div class='lsl-back-button'>  �? <?php echo _e('Back', LSL_TEXT_DOMAIN); ?></div></a>
                    </form>

                </div>
                <div class='lsl-login-form' style='<?php
                if (isset($_POST['lsl_login_details_submit'])) {
                    echo "display:block";
                } else {
                    echo "display:none";
                }
                ?>'>
                    <div class='message-wrapper'> <?php
                        if (isset($error_message)) {
                            echo $error_message;
                        }
                        ?> </div>
                    <form method="post" action="" class="clearfix" id='lsl-username-register'>
                        <div class="lsl-login-user-field-wrapper">
                            <label><?php echo _e('Username:', LSL_TEXT_DOMAIN); ?></label>
                            <div class="lsl-login-user-field lsl-user-username">
                                <input type="text" name="login_username" required="">
                            </div>
                        </div>
                        <div class="lsl-login-user-field-wrapper">
                            <label><?php echo _e('Password:', LSL_TEXT_DOMAIN); ?></label>
                            <div class="lsl-login-user-field lsl-user-password">
                                <input type="password" name="login_password" required="">
                            </div>
                        </div>
                        <div class="lsl-login-field-wrapper">
                            <div class="lsl-login-user-field lsl-submit-login">
                                <input type="submit" name="lsl_login_details_submit" value="<?php echo _e('Continue', LSL_TEXT_DOMAIN); ?>">
                            </div>
                        </div>


                        <a href='javascript:void(0);'><div class='lsl-back-button'> �? <?php echo _e('Back', LSL_TEXT_DOMAIN); ?></div></a></form>
                </div>
            </div>

        </div>
    <?php } else { ?>
        <h1><?php echo _e('You are not allowed to view this page.', LSL_TEXT_DOMAIN); ?></h1>
    <?php } ?>
</body>
<?php wp_footer(); ?>