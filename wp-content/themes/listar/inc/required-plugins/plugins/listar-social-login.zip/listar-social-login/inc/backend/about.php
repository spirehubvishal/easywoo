<div class="about-wrapper clearfix">
        <div class="about-desc-wrap clearfix">
            <div class="lsl-title"> About Listar Social Login</div>
            <div class="about-content">
                <p>Listar<strong>Social Login</strong> - is a perfect WordPress plugin to allow your website users to register/login to the website using one of their favorite social website accounts.</p>       
            </div>
        </div>
    </div>
