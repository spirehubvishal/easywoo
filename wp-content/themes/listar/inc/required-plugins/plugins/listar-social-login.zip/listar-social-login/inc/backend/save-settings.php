<?php defined('ABSPATH') or die('No script kiddies please!'); ?>
<?php

$lsl_settings = array();

if (isset($_POST['lsl_save_settings'])) {
    $lsl_settings['network_ordering'] = $_POST['network_ordering'];

    //for facebook settings
    foreach ($_POST['lsl_facebook_settings'] as $key => $value) {
        $$key = $value;
    }
    $lsl_facebook_enable = isset($lsl_facebook_enable) ? $lsl_facebook_enable : '';

    $facebook_parameters = array(
        'lsl_facebook_enable' => $lsl_facebook_enable,
        'lsl_facebook_app_id' => $lsl_facebook_app_id,
        'lsl_facebook_app_secret' => $lsl_facebook_app_secret,
        'lsl_profile_image_width' => $lsl_profile_image_width,
        'lsl_profile_image_height' => $lsl_profile_image_height
    );
    $lsl_settings['lsl_facebook_settings'] = $facebook_parameters;

    foreach ($_POST['lsl_twitter_settings'] as $key => $value) {
        $$key = $value;
    }
    $lsl_twitter_enable = isset($lsl_twitter_enable) ? $lsl_twitter_enable : '';
    $twitter_parameters = array(
        'lsl_twitter_enable' => $lsl_twitter_enable,
        'lsl_twitter_api_key' => $lsl_twitter_api_key,
        'lsl_twitter_api_secret' => $lsl_twitter_api_secret
    );
    $lsl_settings['lsl_twitter_settings'] = $twitter_parameters;

    foreach ($_POST['lsl_linkedin_settings'] as $key => $value) {
        $$key = $value;
    }
    $lsl_linkedin_enable = isset($lsl_linkedin_enable) ? $lsl_linkedin_enable : '';
    $linkedin_parameters = array(
        'lsl_linkedin_enable' => $lsl_linkedin_enable,
        'lsl_linkedin_client_id' => $lsl_linkedin_client_id,
        'lsl_linkedin_client_secret' => $lsl_linkedin_client_secret
    );
    $lsl_settings['lsl_linkedin_settings'] = $linkedin_parameters;

    foreach ($_POST['lsl_google_settings'] as $key => $value) {
        $$key = $value;
    }
    $lsl_google_enable = isset($lsl_google_enable) ? $lsl_google_enable : '';
    $google_parameters = array(
        'lsl_google_enable' => $lsl_google_enable,
        'lsl_google_client_id' => $lsl_google_client_id,
        'lsl_google_client_secret' => $lsl_google_client_secret
    );
    $lsl_settings['lsl_google_settings'] = $google_parameters;

    foreach ($_POST['lsl_instagram_settings'] as $key => $value) {
        $$key = $value;
    }
    $lsl_instagram_enable = isset($lsl_instagram_enable) ? $lsl_instagram_enable : '';
    $instagram_parameters = array(
        'lsl_instagram_enable' => $lsl_instagram_enable,
        'lsl_instagram_api_key' => $lsl_instagram_api_key,
        'lsl_instagram_api_secret' => $lsl_instagram_api_secret
    );
    $lsl_settings['lsl_instagram_settings'] = $instagram_parameters;

    foreach ($_POST['lsl_foursquare_settings'] as $key => $value) {
        $$key = $value;
    }
    $lsl_foursquare_enable = isset($lsl_foursquare_enable) ? $lsl_foursquare_enable : '';
    $foursquare_parameters = array(
        'lsl_foursquare_enable' => $lsl_foursquare_enable,
        'lsl_foursquare_client_id' => $lsl_foursquare_client_id,
        'lsl_foursquare_client_secret' => $lsl_foursquare_client_secret
    );
    $lsl_settings['lsl_foursquare_settings'] = $foursquare_parameters;

    foreach ($_POST['lsl_wordpress_settings'] as $key => $value) {
        $$key = $value;
    }
    $lsl_wordpress_enable = isset($lsl_wordpress_enable) ? $lsl_wordpress_enable : '';
    $wordpress_parameters = array(
        'lsl_wordpress_enable' => $lsl_wordpress_enable,
        'lsl_wordpress_client_id' => $lsl_wordpress_client_id,
        'lsl_wordpress_client_secret' => $lsl_wordpress_client_secret
    );
    $lsl_settings['lsl_wordpress_settings'] = $wordpress_parameters;

    foreach ($_POST['lsl_vk_settings'] as $key => $value) {
        $$key = $value;
    }
    $lsl_vk_enable = isset($lsl_vk_enable) ? $lsl_vk_enable : '';
    $vk_parameters = array(
        'lsl_vk_enable' => $lsl_vk_enable,
        'lsl_vk_app_id' => $lsl_vk_app_id,
        'lsl_vk_secure_key' => $lsl_vk_secure_key
    );
    $lsl_settings['lsl_vk_settings'] = $vk_parameters;

    foreach ($_POST['lsl_buffer_settings'] as $key => $value) {
        $$key = $value;
    }
    $lsl_buffer_enable = isset($lsl_buffer_enable) ? $lsl_buffer_enable : '';
    $buffer_parameters = array(
        'lsl_buffer_enable' => $lsl_buffer_enable,
        'lsl_buffer_client_id' => $lsl_buffer_client_id,
        'lsl_buffer_client_secret' => $lsl_buffer_client_secret
    );
    $lsl_settings['lsl_buffer_settings'] = $buffer_parameters;

    if (isset($_POST['lsl_tumblr_settings'])) {
        foreach ($_POST['lsl_tumblr_settings'] as $key => $value) {
            $$key = $value;
        }
        $lsl_tumblr_enable = isset($lsl_tumblr_enable) ? $lsl_tumblr_enable : '';
        $tumblr_parameters = array(
            'lsl_tumblr_enable' => $lsl_tumblr_enable,
            'lsl_tumblr_client_id' => $lsl_tumblr_client_id,
            'lsl_tumblr_client_secret' => $lsl_tumblr_client_secret
        );
    } else {
        $tumblr_parameters = array();
    }
    $lsl_settings['lsl_tumblr_settings'] = $tumblr_parameters;

    if (isset($_POST['lsl_reddit_settings'])) {
        foreach ($_POST['lsl_reddit_settings'] as $key => $value) {
            $$key = $value;
        }
        $lsl_reddit_enable = isset($lsl_reddit_enable) ? $lsl_reddit_enable : '';
        $reddit_parameters = array(
            'lsl_reddit_enable' => $lsl_reddit_enable,
            'lsl_reddit_client_id' => $lsl_reddit_client_id,
            'lsl_reddit_client_secret' => $lsl_reddit_client_secret
        );
    } else {
        $reddit_parameters = array();
    }
    $lsl_settings['lsl_reddit_settings'] = $reddit_parameters;

    if (isset($_POST['lsl_yahoo_settings'])) {
        foreach ($_POST['lsl_yahoo_settings'] as $key => $value) {
            $$key = $value;
        }
        $lsl_yahoo_enable = isset($lsl_yahoo_enable) ? $lsl_yahoo_enable : '';
        $yahoo_parameters = array(
            'lsl_yahoo_enable' => $lsl_yahoo_enable,
            'lsl_yahoo_client_id' => $lsl_yahoo_client_id,
            'lsl_yahoo_client_secret' => $lsl_yahoo_client_secret
        );
    } else {
        $yahoo_parameters = array();
    }
    $lsl_settings['lsl_yahoo_settings'] = $yahoo_parameters;

    if (isset($_POST['lsl_weibo_settings'])) {
        foreach ($_POST['lsl_weibo_settings'] as $key => $value) {
            $$key = $value;
        }
        $lsl_weibo_enable = isset($lsl_weibo_enable) ? $lsl_weibo_enable : '';
        $weibo_parameters = array(
            'lsl_weibo_enable' => $lsl_weibo_enable,
            'lsl_weibo_client_id' => $lsl_weibo_client_id,
            'lsl_weibo_client_secret' => $lsl_weibo_client_secret
        );
    } else {
        $weibo_parameters = array();
    }
    $lsl_settings['lsl_weibo_settings'] = $weibo_parameters;

    $lsl_settings['lsl_enable_disable_plugin'] = $_POST['lsl_enable_disable_plugin'];
    $lsl_settings['lsl_enable_disable_buddypress'] = $_POST['lsl_enable_disable_buddypress'];
    $lsl_settings['lsl_enable_disable_woocommerce'] = $_POST['lsl_enable_disable_woocommerce'];
    $lsl_settings['lsl_enable_disable_edd_login_shortcode'] = $_POST['lsl_enable_disable_edd_login_shortcode'];
    $lsl_settings['lsl_enable_disable_edd_register_shortcode'] = $_POST['lsl_enable_disable_edd_register_shortcode'];
    $lsl_settings['lsl_enable_disable_edd_checkout'] = $_POST['lsl_enable_disable_edd_checkout'];
    $display_options = array();
    if (isset($_POST['lsl_display_options'])) {
        foreach ($_POST['lsl_display_options'] as $key => $value) {
            $display_options[] = $value;
        }
    }

    $lsl_settings['lsl_display_options'] = $display_options;
    $lsl_settings ['lsl_user_role'] = $_POST['lsl_user_role'];
    $lsl_settings['lsl_icon_theme'] = $_POST['lsl_icon_theme'];
    $lsl_settings['lsl_title_text_field'] = $_POST['lsl_title_text_field'];
    $lsl_settings['lsl_login_short_text'] = $_POST['lsl_login_short_text'];
    $lsl_settings['lsl_login_with_long_text'] = $_POST['lsl_login_with_long_text'];
    $lsl_settings['lsl_each_link_title_attribute'] = $_POST['lsl_each_link_title_attribute'];
    $lsl_settings['lsl_login_error_message'] = $_POST['lsl_login_error_message'];
    $lsl_settings['lsl_custom_logout_redirect_options'] = $_POST['lsl_custom_logout_redirect_options'];
    $lsl_settings['lsl_custom_logout_redirect_link'] = $_POST['lsl_custom_logout_redirect_link'];
    $lsl_settings['lsl_custom_login_redirect_options'] = $_POST['lsl_custom_login_redirect_options'];
    $lsl_settings['lsl_custom_login_redirect_link'] = $_POST['lsl_custom_login_redirect_link'];
    $lsl_settings['lsl_user_avatar_options'] = $_POST['lsl_user_avatar_options'];
    $lsl_settings['lsl_send_email_notification_options'] = $_POST['lsl_send_email_notification_options'];
    $lsl_settings['lsl_email_sender_email'] = $_POST['lsl_email_sender_email'];
    $email_body = stripslashes_deep($_POST['lsl_email_body']);

    $lsl_settings['lsl_email_body'] = self:: sanitize_escaping_linebreaks($email_body);

    $lsl_settings['lsl_custom_username_allow'] = isset($_POST['lsl_custom_username_allow']) ? $_POST['lsl_custom_username_allow'] : false;
    $lsl_settings['lsl_custom_email_allow'] = isset($_POST['lsl_custom_email_allow']) ? $_POST['lsl_custom_email_allow'] : false;
    $lsl_settings['lsl_profile_mapping_options'] = isset($_POST['lsl_profile_mapping_options']) ? $_POST['lsl_profile_mapping_options'] : 'no';
    $lsl_settings['lsl_settings_buddypress_xprofile_map'] = isset($_POST['lsl_settings_buddypress_xprofile_map']) ? $_POST['lsl_settings_buddypress_xprofile_map'] : array();
    //Since Version 2.0.0. Newly Added Settings
    $lsl_settings['lsl_user_login_allowed_type'] = isset($_POST['lsl_user_login_allowed_type']) ? $_POST['lsl_user_login_allowed_type'] : 'yes';
    $lsl_settings['lsl_login_non_registered_info_text'] = isset($_POST['lsl_login_non_registered_info_text']) ? sanitize_text_field($_POST['lsl_login_non_registered_info_text']) : __('Sorry. Only registered user can log in.', LSL_TEXT_DOMAIN);
    $lsl_settings['lsl_disable_autoclose_login_window'] = isset($_POST['lsl_disable_autoclose_login_window']) ? $_POST['lsl_disable_autoclose_login_window'] : 'enable';
    $lsl_settings['lsl_add_no_follow_in_login_link'] = isset($_POST['lsl_add_no_follow_in_login_link']) ? $_POST['lsl_add_no_follow_in_login_link'] : 'no';
    
    $lsl_settings['lsl_showhide_title_attr'] = isset($_POST['lsl_showhide_title_attr']) ? $_POST['lsl_showhide_title_attr'] : 'show';
    update_option(LSL_SETTINGS, $lsl_settings);
    $_SESSION['lsl_message'] = __('Settings Saved Successfully.', LSL_TEXT_DOMAIN);
    wp_redirect(admin_url() . 'admin.php?page=lsl');
    exit;
}