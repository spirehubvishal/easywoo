<?php
/**
 * Plugin Name: Listar Customer Snippets
 * Description: This plugin has only one PHP file and, by default, it is empty and does nothing. Use this file exclusively to paste PHP codes suggested by the theme developer, mainly WordPress filters/actions and quick fixes. This is a helpful support plugin for customers that does not have a Child theme installed and intends to avoid the original theme files get touched/modified. Almost "rare" usage cases... but we are thinking on all possibilities for you.
 * Author: Web Design Trade
 * Author URI: https://themeforest.net/user/webdesigntrade
 * Text Domain: listar
 * Domain Path: /languages/
 * Version: 1.0.0
 *
 * @package Listar_Customer_Snippets
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}
