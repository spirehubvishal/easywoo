=== Listar Customer Snippets ===
Contributors: Theme Server
Requires at least: 4.7.0
Tested up to: 5.8.1
Stable tag: 1.0.0
License: GNU General Public License v3.0

This plugin has only one PHP file and, by default, it is empty and does nothing. Use this file exclusively to paste PHP codes suggested by the theme developer, mainly WordPress filters/actions and quick fixes. This is a helpful support plugin for customers that does not have a Child theme installed.

= Documentation =

Just install and activate the plugin, no configuration needed.

= Support Policy =

Please contact https://themeforest.net/user/webdesigntrade/ for technical support regarding the plugin.

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Other Notes ==

== Changelog ==

= 1.0.0: October 26, 2021 =

Initial release.