<?php
/**
 * Load 3rd party compatibility tweaks.
 */
require_once JOB_MANAGER_WCPL_PLUGIN_DIR . '/includes/3rd-party/wpml.php';
