=== Listar Add-ons ===
Contributors: Theme Server
Requires at least: 4.7.0
Tested up to: 6.7
Stable tag: 1.5.4.93
License: GNU General Public License v3.0

This plugin provides some of the functionality for the Listar theme: create new taxonomies, customize WP Job Manager taxonomy labels, register widgets and custom meta boxes, and so on.

= Documentation =

Just install and activate the plugin, no configuration needed.

= Support Policy =

Please contact https://themeforest.net/user/webdesigntrade/ for technical support regarding the plugin.

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Other Notes ==

== Changelog ==

=  Since version 1.4.0.2, all changelog for this plugin is being reported directly on Listar Directory theme's changelog file: [...]/listar/readme.txt.