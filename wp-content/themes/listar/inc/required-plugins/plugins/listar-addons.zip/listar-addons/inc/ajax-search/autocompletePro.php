<?php
header("Access-Control-Allow-Origin: *");
?>
[{"text":"Testar","id":5},
{"text":"Glanda","id":6},
{"text":"Brudir","id":7},
{"text":"Tesla","id":9}]